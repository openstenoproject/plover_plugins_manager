Plover Template System
======================
